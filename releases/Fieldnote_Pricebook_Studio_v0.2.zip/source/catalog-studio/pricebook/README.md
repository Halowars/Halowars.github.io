# Pricebook Studio source

From the parent catalog-studio folder, run node tests.cjs, node pricebook/tests.cjs and node pricebook/build.cjs. The last command creates pricebook/index.html and samples. See ENGINEERING.md and the operating guides at the delivery ZIP root.
