# Tristan: seller kit

Start with TRISTAN_START_HERE.md. This package is for your sales and delivery process; do not send it as the buyer software package. Proposed price is $12,500, subject to sample fit and buyer validation. Software delivery is the separate Fieldnote_Pricebook_Studio_v0.2.zip file.
